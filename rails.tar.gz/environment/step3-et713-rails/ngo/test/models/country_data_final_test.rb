require "test_helper"

class CountryDataFinalTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
