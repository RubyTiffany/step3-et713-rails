class CountryDataFinal < ApplicationRecord
end
